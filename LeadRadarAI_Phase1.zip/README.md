# LeadRadar AI

Phase 1 scaffold.

## Stack
- Next.js (frontend)
- FastAPI (backend)
- PostgreSQL

This is the initial project structure.
